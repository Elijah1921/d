import discord
from discord.ext import commands
import json
import asyncio
import os
import sys
bot = commands.Bot(command_prefix='?')
with open(os.path.join(sys.path[0], "config.json"), "r") as f:
    config = json.load(f)
    message = config["message"]
    token = config["token"]
    delay = int(config["delay"])
@bot.event
async def on_ready():
    print(' [!] Started Dmming Ids\n')

    with open("ids.json", "r") as file:
        data = json.load(file)

    indx = 0
    for i in data:
        indx += 1
        member = await bot.fetch_user(i)
        try:
            await member.send(message)
            print(f" [+] Sent message {indx} / {len(data)}")
            await asyncio.sleep(delay)
        except Exception as e:
            print(f" [!] {e}")

    print(" [+] Done")

bot.run(token, bot = False)